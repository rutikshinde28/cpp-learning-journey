#include<iostream>
using namespace std;
int main()
{
    int x = 10;
    cout << x << endl;
    x = 20;
    cout << x << endl;
    x = x+5;
    cout << x << endl;
    x = x*2;
    cout << x << endl;
    return 0;
}