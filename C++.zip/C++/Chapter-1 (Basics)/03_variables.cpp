#include<iostream>
using namespace std;
int main()
{
    int x, y;
    x=10;
    y=20;
    cout << x+y*2;
    return 0;   
}